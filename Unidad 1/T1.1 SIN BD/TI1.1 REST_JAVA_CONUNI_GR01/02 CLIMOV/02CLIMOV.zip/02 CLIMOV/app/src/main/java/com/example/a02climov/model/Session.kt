package com.example.a02climov.model

data class Session(val user: String)
